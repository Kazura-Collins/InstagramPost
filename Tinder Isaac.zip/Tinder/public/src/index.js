import * as components from "./components/index.js"

class AppContainer extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback(){
        this.render();
    }

    render(){
        this.shadowRoot.innerHTML = `
        <my-profile></my-profile>
        `
    }
}


class CounterContainer extends AppContainer{

    render(){
        this.shadowRoot.innerHTML = `
        <div class="actionBtns">
            <my-counter></my-counter>
            <my-counter2></my-counter2>
        </div>
        `
    }
}

customElements.define("app-container",AppContainer);
customElements.define("counter-container",CounterContainer);