class MyProfile extends HTMLElement {
  static get observedAttributes() {
    return ['name', 'lastname', 'age'];
  }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }
  connectedCallback() {
    this.render();
  }


  attributeChangedCallback(propName, oldValue, newValue) {
    this[propName] = newValue;
    this.render();
  }

  render() {
    this.shadowRoot.innerHTML = `
        <link rel="stylesheet" href="./src/components/profile/style.css">
        <section>
        <div class="card">
        <div class="top">
        </div>
        <div class="imgBx">
            <img src="./images/Jhoho.jpeg" class="cover" alt="post foto Kazura">
        </div>
        <h4 class="message"><b>Jhohocor</b> <br>No sé qué hago en esta app xd <span>#minecraft</span> <span>#espantaviejas</span> <span>#shinji</span></h4>
        <counter-container></counter-container>
        
        </div>
    
        </section>
        `;
  }
}

customElements.define('my-profile', MyProfile);
export default MyProfile;
